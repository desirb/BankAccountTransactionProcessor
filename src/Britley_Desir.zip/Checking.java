public class Checking extends Account{
	private int numCheck;
	private int maxCheck;

	public Checking(int number, String owner, double balance, int numCheck, int maxCheck) {
		super(number, owner, balance);
		this.numCheck = numCheck;
		this.maxCheck = maxCheck;
	}

	public void withdraw(Account a, double amt, String owner) {
		if (((Checking) a).numCheck > ((Checking) a).maxCheck) {
			System.out.println("You have reached your maximum check amount of " + ((Checking) a).maxCheck + ". This transaction could not be completed.");
		}else if (a.getOwner().equalsIgnoreCase(owner) == false){
			System.out.println("The owner of the account could not be verified. This transaction could not be completed.");
		}else {
		((Checking) a).numCheck +=1;
		a.setBalance(a.getBalance() - amt);
		}
	}

	public void deposit(Account a, double amt) {
		if (((Checking) a).numCheck > ((Checking) a).maxCheck) {
			System.out.println("You have reached your maximum check amount of " + ((Checking) a).maxCheck + ". This transaction could not be completed.");
		}else {
			((Checking) a).numCheck +=1;
			a.setBalance(a.getBalance() + amt);
		}
	}

	public void close(Account a, String owner) {
		if (a.getBalance() < 0) {
			System.out.println("The balance of $" + a.getBalance() + " does not meet the requirements for this type of transaction. This transaction could not be completed.");
		}else if (a.getOwner().equalsIgnoreCase(owner) == false) {
			System.out.println("The owner of the account could not be verified. This transaction could not be completed.");
		}else {
			a.setNumber(0);
		}
	}
	
	public void transfer(Account a, Account b, double amt, String owner) {
		if (((Checking) a).numCheck > ((Checking) a).maxCheck) {
			System.out.println("You have reached your maximum check amount of " + ((Checking) a).maxCheck + ". This transaction could not be completed.");
		}else if (a.getOwner().equalsIgnoreCase(owner) == false){
			System.out.println("The owner of the account could not be verified. This transaction could not be completed.");
//		}else if (b instanceof Checking) {
//			if(((Checking) b).numCheck > ((Checking) b).maxCheck) {
//			System.out.println("Account " + b.getNumber() + " has reached it's maximum check usage amount of " + ((Checking) a).maxCheck + ". This transaction could not be completed.");
//			}else {
//				((Checking) a).numCheck +=1;
//				((Checking) b).numCheck +=1;
//				a.setBalance(a.getBalance() - amt);
//				b.setBalance(b.getBalance() + amt);
//			}
		}else {
			((Checking) a).numCheck +=1;
			((Checking) b).numCheck +=1;
			a.setBalance(a.getBalance() - amt);
			b.setBalance(b.getBalance() + amt);
		}
	}
	

	public int getNumCheck() {
		return numCheck;
	}

	public void setNumCheck(int numCheck) {
		this.numCheck = numCheck;
	}


	public int getMaxCheck() {
		return maxCheck;
	}


	public void setMaxCheck(int maxCheck) {
		this.maxCheck = maxCheck;
	}

}
